#!/usr/bin/env bash
# page_faults.sh - counts page faults for the vm benchmark at each footprint.
# gem5 SE mode has no page-fault statistic, so the SimpleCPU debug trace is
# filtered for its "Fault occured" message (one per fault taken by the CPU).
ROOT=$(cd "$(dirname "$0")" && pwd)
GEM5=~/mscs531/gem5
echo "pages,page_faults"
for p in 32 64 128 256 512 1024; do
    n=$($GEM5/build/X86/gem5.opt -d "$ROOT/runs/pf_$p" --debug-flags=SimpleCPU \
        "$ROOT/configs/se_custom.py" --cpu-type=X86TimingSimpleCPU --caches --l2cache \
        -c "$ROOT/bench/vm" -o "$p 4096 50" 2>/dev/null | grep -c 'Fault occured')
    echo "$p,$n"
done
