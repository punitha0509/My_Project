/* mm.c - cache benchmark: naive i-j-k double-precision matrix multiply.
 * C = A x B, N x N. The inner loop walks B down a column (stride N*8 bytes),
 * so the workload is sensitive to cache size, associativity and block size.
 * Optional 2nd argument pads each row by `pad` doubles (leading dimension
 * ld = n + pad), which breaks the power-of-two stride. */
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
    int n = argc > 1 ? atoi(argv[1]) : 128;
    int ld = n + (argc > 2 ? atoi(argv[2]) : 0);
    double *a = malloc(sizeof(double) * n * ld);
    double *b = malloc(sizeof(double) * n * ld);
    double *c = malloc(sizeof(double) * n * ld);
    for (int i = 0; i < n; i++)
        for (int j = 0; j < ld; j++) {
            a[i * ld + j] = ((i * n + j) % 7) + 1.0;
            b[i * ld + j] = ((i * n + j) % 5) + 1.0;
            c[i * ld + j] = 0.0;
        }
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++) {
            double sum = 0.0;
            for (int k = 0; k < n; k++)
                sum += a[i * ld + k] * b[k * ld + j];
            c[i * ld + j] = sum;
        }
    double check = 0.0;
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            check += c[i * ld + j];
    printf("mm: N=%d ld=%d checksum=%.1f\n", n, ld, check);
    return 0;
}
