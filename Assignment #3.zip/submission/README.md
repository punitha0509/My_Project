# MSCS-531 Assignment 3: Exploring Memory Hierarchy Design in gem5

Cache-configuration and virtual-memory experiments in gem5 v25.1.0.1 (x86, syscall-emulation mode,
`X86TimingSimpleCPU`). The full write-up is `Assignment3_Report.docx`.

## Layout

| Path | Contents |
|---|---|
| `bench/mm.c` | Cache benchmark: 128 x 128 double matrix multiply, optional row padding (`mm 128 8`) |
| `bench/vm.c` | Virtual-memory benchmark: touches N pages, then sweeps them with a given stride |
| `configs/se_custom.py` | Wrapper around `configs/deprecated/example/se.py` that adds `--l1d-rp=<policy>` |
| `configs/experiments.txt` | Every experiment: name, gem5 options, benchmark, arguments |
| `run_all.sh` | Runs the experiments (10 in parallel) into `runs/<name>/` |
| `page_faults.sh` | Counts page faults from the SimpleCPU debug trace -> `page_faults.csv` |
| `parse_stats.py` | Extracts hit/miss rates, AMAT, CPI and TLB miss rates -> `results.csv` |
| `make_graphs.py` | Draws `graphs/*.png` from `results.csv` |
| `make_report.py` | Builds `Assignment3_Report.docx` (APA 7) |
| `runs/` | `stats.txt`, `config.ini`, `config.json` and console output of every run |
| `screenshots/`, `logs/` | Screenshots used in the report and saved command output / errors |

## Reproduce

```bash
cd bench && gcc -O2 -static mm.c -o mm && gcc -O2 -static vm.c -o vm && cd ..
bash run_all.sh                 # all experiments (~5 min on 12 threads)
bash page_faults.sh > page_faults.csv
python parse_stats.py && python make_graphs.py && python make_report.py
```

`run_all.sh` expects the gem5 build at `~/mscs531/gem5/build/X86/gem5.opt`.
