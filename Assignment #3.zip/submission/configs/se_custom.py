# se_custom.py - thin wrapper around gem5's configs/deprecated/example/se.py.
# Adds one option that se.py lacks:
#   --l1d-rp=NAME   replacement policy of the L1 data cache (e.g. LRURP, RandomRP, BRRIPRP)
# Every other option is passed to se.py unchanged.
import os
import runpy
import sys

GEM5 = os.path.expanduser("~/mscs531/gem5")
SE_PY = os.path.join(GEM5, "configs/deprecated/example/se.py")
sys.path.insert(0, os.path.join(GEM5, "configs"))

import m5.objects
from common import Caches

rp = [a for a in sys.argv if a.startswith("--l1d-rp=")]
if rp:
    sys.argv.remove(rp[0])
    Caches.L1_DCache.replacement_policy = getattr(m5.objects, rp[0].split("=", 1)[1])()

sys.argv[0] = SE_PY
runpy.run_path(SE_PY, run_name="__main__")
