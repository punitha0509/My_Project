# parse_stats.py - pulls the metrics used in the report out of runs/*/stats.txt into results.csv
import csv, glob, os, re

ROOT = os.path.dirname(os.path.abspath(__file__))
TICKS_PER_CYCLE = 500   # 2 GHz CPU clock (system.cpu_clk_domain clock=500 in config.ini)
L1_HIT_CYCLES = 2       # max(tag_latency, data_latency) of L1Cache in configs/common/Caches.py

KEYS = {
    "sim_seconds": "simSeconds", "insts": "simInsts",
    "cycles": "system.cpu.numCycles", "cpi": "system.cpu.cpi",
    "l1d_acc": "system.cpu.dcache.overallAccesses::total",
    "l1d_hits": "system.cpu.dcache.overallHits::total",
    "l1d_miss": "system.cpu.dcache.overallMisses::total",
    "l1d_miss_rate": "system.cpu.dcache.overallMissRate::total",
    "l1d_miss_lat": "system.cpu.dcache.overallAvgMissLatency::total",
    "l1i_miss_rate": "system.cpu.icache.overallMissRate::total",
    "l2_acc": "system.l2.overallAccesses::total",
    "l2_miss": "system.l2.overallMisses::total",
    "l2_miss_rate": "system.l2.overallMissRate::total",
    "pf_issued": "system.cpu.dcache.prefetcher.pfIssued",
    "pf_useful": "system.cpu.dcache.prefetcher.pfUseful",
    "l2pf_issued": "system.l2.prefetcher.pfIssued",
    "l2pf_useful": "system.l2.prefetcher.pfUseful",
    "dtb_rd_acc": "system.cpu.mmu.dtb.rdAccesses", "dtb_wr_acc": "system.cpu.mmu.dtb.wrAccesses",
    "dtb_rd_miss": "system.cpu.mmu.dtb.rdMisses", "dtb_wr_miss": "system.cpu.mmu.dtb.wrMisses",
}

rows = []
for stats in sorted(glob.glob(os.path.join(ROOT, "runs", "*", "stats.txt"))):
    vals = {}
    with open(stats) as f:
        for line in f:
            parts = line.split()
            if len(parts) >= 2 and parts[0] in KEYS.values() and parts[0] not in vals:
                vals[parts[0]] = float(parts[1]) if parts[1] not in ("nan", "inf") else 0.0
    if not vals.get("simInsts"):
        print("skipping failed run", stats)
        continue
    r = {"name": os.path.basename(os.path.dirname(stats))}
    for k, v in KEYS.items():
        r[k] = vals.get(v, 0.0)
    r["l1d_hit_rate"] = 1 - r["l1d_miss_rate"]
    r["l1d_miss_lat_cyc"] = r["l1d_miss_lat"] / TICKS_PER_CYCLE
    r["amat_cyc"] = L1_HIT_CYCLES + r["l1d_miss_rate"] * r["l1d_miss_lat_cyc"]
    acc = r["dtb_rd_acc"] + r["dtb_wr_acc"]
    r["dtb_acc"], r["dtb_miss"] = acc, r["dtb_rd_miss"] + r["dtb_wr_miss"]
    r["dtb_miss_rate"] = r["dtb_miss"] / acc if acc else 0.0
    rows.append(r)

cols = ["name", "sim_seconds", "insts", "cycles", "cpi", "l1d_acc", "l1d_hits", "l1d_miss",
        "l1d_hit_rate", "l1d_miss_rate", "l1d_miss_lat_cyc", "amat_cyc", "l1i_miss_rate",
        "l2_acc", "l2_miss", "l2_miss_rate", "pf_issued", "pf_useful", "l2pf_issued", "l2pf_useful",
        "dtb_acc", "dtb_miss", "dtb_miss_rate"]
with open(os.path.join(ROOT, "results.csv"), "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
    w.writeheader()
    w.writerows(rows)
print(f"wrote results.csv ({len(rows)} runs)")
