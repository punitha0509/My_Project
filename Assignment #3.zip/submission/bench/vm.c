/* vm.c - virtual-memory benchmark.
 * Allocates `pages` 4 KiB pages, touches each one once (first-touch page
 * faults), then makes `passes` sweeps that read one 8-byte word per `stride`
 * bytes. With stride >= 4096 every access lands on a different page, so the
 * TLB must hold `pages` entries to avoid misses. */
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
    long pages  = argc > 1 ? atol(argv[1]) : 256;
    long stride = argc > 2 ? atol(argv[2]) : 4096;
    int  passes = argc > 3 ? atoi(argv[3]) : 20;
    long bytes = pages * 4096;
    volatile unsigned char *buf = malloc(bytes);
    for (long i = 0; i < bytes; i += 4096)      /* first touch */
        buf[i] = (unsigned char)(i >> 12);
    long sum = 0;
    for (int p = 0; p < passes; p++)
        for (long i = 0; i < bytes; i += stride)
            sum += buf[i];
    printf("vm: pages=%ld stride=%ld passes=%d sum=%ld\n", pages, stride, passes, sum);
    return 0;
}
