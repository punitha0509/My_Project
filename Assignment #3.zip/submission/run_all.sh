#!/usr/bin/env bash
# run_all.sh - runs every line of configs/experiments.txt through gem5 (10 at a time).
# Each run writes runs/<name>/{stats.txt,config.ini,console.txt}.
# Usage: bash run_all.sh            (all experiments)
#        bash run_all.sh c_base     (only names matching a pattern)
ROOT=$(cd "$(dirname "$0")" && pwd)
GEM5=~/mscs531/gem5
COMMON="--cpu-type=X86TimingSimpleCPU --caches --l2cache"
export ROOT GEM5 COMMON

run_one() {
    IFS='|' read -r name opts bin args <<< "$1"
    name=$(echo $name); bin=$(echo $bin); args=$(echo $args)
    out=$ROOT/runs/$name
    rm -rf "$out"; mkdir -p "$out"
    eval "$GEM5/build/X86/gem5.opt -d $out $ROOT/configs/se_custom.py $COMMON $opts -c $ROOT/bench/$bin -o '$args'" \
        > "$out/console.txt" 2>&1
    echo "done $name ($(grep -m1 simSeconds "$out/stats.txt" | awk '{print $2}') s simulated)"
}
export -f run_one

grep -v '^#' "$ROOT/configs/experiments.txt" | grep -E "${1:-.}" | tr '\n' '\0' | xargs -0 -P 10 -I{} bash -c 'run_one "$@"' _ {}
